import pandas as pd

orders = pd.read_csv ("../2020-Sales.csv")

orders = orders.drop(columns=['Shipping Method'])

orders['Profit'] = orders['Sales'] - orders['Cost']

orders['Last Name'] = orders['Customer Name'].str.split(' ').str.get(1)
orders['Customer Name'] = orders['Customer Name'].str.split(' ').str.get(0)
orders.rename(columns = {'Customer Name':'First Name'}, inplace = True)

orders = orders.sort_values(by=['Order Month', 'Last Name', 'First Name'])

orders.to_csv(r"../2020-Sales-Clean.csv")

print(orders)

