import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="P@ssw0rd12!",
    database="wwproducts")

mycursor = mydb.cursor()

sql = "INSERT INTO products (product, price) VALUES (%s, %s)"
val = [
    ("Lumber-2x4x96 inch",5.50),
    ("Lumber-2x6x96 inch",8.50),
    ("Lumber-2x4x96 inch Treated",8.75),
    ("Lumber-2x6x96 inch Treated",13.25),
    ("Plywood-1/4x48x96 inch",33.00),
    ("Plywood-1/2x48x96 inch",37.25),
    ("Plywood-1/2x48x96 inch Particleboard",19.25)
]

mycursor.executemany(sql, val)

mydb.commit()
mydb.close()

print(mycursor.rowcount, "records inserted in products table.")

